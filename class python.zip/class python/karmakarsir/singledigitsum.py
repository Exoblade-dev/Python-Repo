a=int(input("Enter a number:"))
