s1 ='hello world'
print(s1)
s2 ="python programming"
print(s2)

s3='''This is multi line string'''
print(s3)

s4=str(123)
print(s4)

path=r"c/Users/samrat/python"
print(path)

name="Alice"
greeting=f"Hello {name}!" #formatted string

print(greeting)