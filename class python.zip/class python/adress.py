a=4
b=a
c=6
print(a is b)
print(a is c)
print(b is c)
print(id(a))
print(id(b))
print(id(c))
