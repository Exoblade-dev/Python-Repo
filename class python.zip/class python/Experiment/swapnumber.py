a=int(input("Enter 1st number:"))
b=int(input("Enter 2nd number:"))
# a=a+b
# b=a-b
# a=a-b

#2nd method
(a,b)=(b,a)
print("1st number is :",a)
print("2nd number is:",b)