from datetime import datetime
now =datetime.now()
print("current date and time :" ,now.strftime("%y-%m-%d  %H:%M:%S"))