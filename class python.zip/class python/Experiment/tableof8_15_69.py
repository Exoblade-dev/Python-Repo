def table(n):
    print("table of:",n)
    for i in range(1,11):
        print(n*i)
        
        
        
table(8)
table(15)
table(69)
