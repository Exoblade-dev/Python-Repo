li=[1,2,3,4,5]
li.append(5)
print(li)

li=li+[6]
print(li)
b=[7,8,9]
li.extend(b)
print(li)
li.insert(2,23)
print(li)

print(li[2: :1])
print(li[2:5])
print(li[ :5:1])
