def calculate(x,y):
    addition=x+y
    subtration=x-y
    multiplication=x*y
    return addition,subtration,multiplication
add,sub,mul=calculate(5,2)
print(add,sub,mul)