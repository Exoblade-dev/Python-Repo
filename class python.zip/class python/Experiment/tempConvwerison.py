cel=float(input("Enter temperature in degree:"))

farn=(cel*1.8)+32
 
print("Entered temperature in farnheit:",farn)
 