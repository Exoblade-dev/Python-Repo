li=["hello","hi","world"]
print(li[2][-1])