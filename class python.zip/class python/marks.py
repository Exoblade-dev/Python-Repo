pps=19
math=18
bee=16
it=16
percent=(pps+math+bee+it)*100/80
print("percent",percent)
