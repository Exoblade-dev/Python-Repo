 a=int(input("Enter a number:"))
 if( a%4==0 or (a%100 == 0 and a%400 == 0)):
     print("Entered number is a leap year")
 else:
      print("Entered number is not a leap year")
# a=4
# b=4
# c=a
# print(a==b)
# print(a==c)