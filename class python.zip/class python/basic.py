# print('''
#         *
#       * *
#     * * *
#   * * * *
# * * * * *
# ''')

a="samrat"
b=float(1.2)
c=int(7)
print(type(a))
print(type(b))
print(type(c))