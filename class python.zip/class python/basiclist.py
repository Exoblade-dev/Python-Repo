students=["bijay","Vishal","sonu","virat","Rohit"]
# print(students[2])

print("sonu" in students) 
print("samrat" in students) 

for student in students:
 print(student)
 
 
print(students[1:4])
print(students[-1:2])