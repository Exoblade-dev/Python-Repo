weight,height=map(int,input("Enter weight(in kg) and height(in meter):").split())
BMI=weight/height
print("BMI is",BMI)