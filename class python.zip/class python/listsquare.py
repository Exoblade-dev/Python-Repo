li=[1,2,3,4,5]

for i in (0,5):
    li[i]=li[i]*li[i]
    i+=1
    
    
print(li)