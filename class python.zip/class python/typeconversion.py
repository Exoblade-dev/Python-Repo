a="samrat"
print(type(a))
a=2
print(type(a))
