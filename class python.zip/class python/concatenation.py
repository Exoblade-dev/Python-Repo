name="samrat"
print("hello " + name)