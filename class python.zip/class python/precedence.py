a=(8-3)*4/3**2
print(float(a))