import random

a=21

b=random.randint(1,5)

c=5-b



