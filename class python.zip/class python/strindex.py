str='text'

 #assignment not valid in string
 # str[0]='u' 

print(str[0])
print(str[-2])