def sum(a,b):
    sum=a+b
    print(sum)
    
    
a=int(input("Enter a number:"))
b=int(input("Enter a number:"))
sum(a,b)
