name="samrat"
age=21
print(f"My name is {name} and i am {age} years old.")