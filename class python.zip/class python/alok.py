a=print
print(type(a))
