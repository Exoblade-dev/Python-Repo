age,weight=map(int,input("Enter age and weight:").split())
print("age and weight",age,weight)