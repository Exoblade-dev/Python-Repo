import math
a,b=map(int,input("Enter two co-ordinates(Enter big number first):").split())
math.sqrt(c)=(math.sqrt(a)-math.sqrt(b))
