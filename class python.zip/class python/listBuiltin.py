a=[2,1,3,4,5,6]
print(len(a))
print(max(a))
print(min(a))
print(sorted(a))
print(sum(a))